import java.util.ArrayList;

public class Database{
    // Create an arraylist of entertainment objects
    private ArrayList<entertainment> mediaList;

    // Constructor
    public Database(){
        mediaList = new ArrayList<entertainment>();
    }

    // Getters and Setters
    public void addMedia(entertainment media){
        mediaList.add(media);
    }

    public void removeMedia(entertainment media){
        mediaList.remove(media);
    }

    // Print out the database
    public void printDatabase(){
        for(int i = 0; i < mediaList.size(); i++){
            System.out.println(mediaList.get(i).writeOutput());
        }
    }
}

