public class TvShow extends entertainment{
    // Instance Variables
    public int seasons;

    // Constructor from entertainment class with additional seasons variable
    public TvShow(String title, String director, String country, int year, String rating, int seasons, String genre) {
        super(title, director, country, year, rating, genre);
        this.seasons = seasons;
    }

    // WriteOutput method to print out the TvShow object
    public String writeOutput() {
        return "Tv Show Title: " + title + "\nTv Show Director: " + director + "\nTv Show Country: " + country + "\nTv Show Year: " + year + "\nTv Show Rating: " + rating + "\nTv Show Duration: " + seasons + "\nTv Show Genre: " + genre;
    }

    // Getters and Setters
    public int getSeasons() {
        return seasons;
    }

    public void setSeasons(int seasons) {
        this.seasons = seasons;
    }
}