public class entertainment {
    // Instance variables
    String title;
    String director;
    String country;
    int year;
    String rating;
    String genre;

    // Constructor
    public entertainment(String title, String director, String country, int year, String rating, String genre) {
        this.title = title;
        this.director = director;
        this.country = country;
        this.year = year;
        this.rating = rating;
        this.genre = genre;
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public String getDirector() {
        return director;
    }

    public String getCountry() {
        return country;
    }

    public int getYear() {
        return year;
    }

    public String getRating() {
        return rating;
    }

    public String getGenre() {
        return genre;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    // toString method
    public String writeOutput() {
        return "Title: " + title + " Director: " + director + " Country: " + country + " Year: " + year + " Rating: " + rating + " Genre: " + genre;
    }
}